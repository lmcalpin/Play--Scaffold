/**
 * 
 */
package play.modules.scaffold.form;

public enum FormElementType
{
	TEXT, CHECKBOX, SELECT, DATE, TEXTAREA;
}